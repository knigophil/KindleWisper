# KindleWisper
Sending Kindle books and optionally stamped covers to device (based on KindleButler)
